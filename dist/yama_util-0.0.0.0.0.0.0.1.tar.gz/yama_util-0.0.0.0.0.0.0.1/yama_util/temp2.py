def yama2():
    return 'Hello Yama Util ๒๒๒๒๒๒๒'