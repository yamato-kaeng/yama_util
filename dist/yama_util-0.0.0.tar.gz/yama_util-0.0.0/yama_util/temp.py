def yama():
    return 'Hello Yama Util'